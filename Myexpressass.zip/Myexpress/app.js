const express = require('express');
const axios = require('axios'); // For making HTTP requests
const app = express();
const port = 8008;

// Define the /numbers route
app.get('/numbers', async (req, res) => {
  const urlList = req.query.url; // Get the array of URLs from query parameters

  if (!Array.isArray(urlList)) {
    return res.status(400).json({ error: 'Invalid input format' });
  }

  const fetchPromises = urlList.map(async (url) => {
    try {
      const response = await axios.get(url, { timeout: 500 });
      return response.data.numbers || []; // Assuming the remote API returns a JSON with a "numbers" property
    } catch (error) {
      console.error(`Error fetching ${url}: ${error.message}`);
      return [];
    }
  });

  try {
    const results = await Promise.all(fetchPromises);
    const mergedNumbers = [...new Set(results.flat())].sort((a, b) => a - b);

    res.json({ numbers: mergedNumbers });
  } catch (error) {
    console.error(`Error processing requests: ${error.message}`);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
